Copyright © 2023-2026 Apple Inc. All Rights Reserved.

Supported Platforms:
-------------------

RHEL9.5 (Plow)
--------------
* Intel x86_64
* RPM version 4.16.1.3 or higher
* man 2.9.3 or higher
* tar 1.34 or higher
* sha256sum 8.32 or higher
* curl 7.76.1 or higher
* openssl 3.0.7 or higher
* zlib 1.2.11 or higher

Ubuntu 24.04.4 LTS
------------------
* Intel x86_64
* dpkg version 1.22.6 or higher
* man 2.9.3 or higher
* tar 1.35 or higher
* sha256sum 9.4 or higher
* curl 8.5.0 or higher
* openssl 3.0.13 or higher
* zlib 1.3.1 or higher

Debian 13.2 (trixie)
--------------------
* Intel x86_64
* dpkg version 1.22.11 or higher
* man 2.13.1 or higher
* tar 1.35 or higher
* sha256sum 9.7 or higher
* curl 8.14.1 or higher
* openssl 3.5.4 or higher
* zlib 1.3.1 or higher

Following steps will help with the installation of HLS tools.

* Please ensure your platform is supported (See above)

* Download HLS tools tgz file your platform from Apple Developer portal.

* Extract .tgz and generate SHA256 hash for the .tar file contained in the .tgz

* Compare your generated .sha256 with .sha256 contained in .tgz

* If hash matches, untar the .tar file and run deploy.sh from the terminal.

* Alternative to generating .sha256 is you can run 'sha256sum --check' on the .sha256 file contained in tgz

* Review license agreement and proceed with the installation.

* HLS tools can be uninstalled by running 'deploy.sh -e'

* Please refer to HLSToolsReadMe.md for more information about the tools.